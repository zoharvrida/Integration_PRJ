/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsm.scheduler.model;

import bdsm.model.BaseModel;

/**
 *
 * @author NCBS
 */
public class UcpTmpSrc extends BaseModel {

    private String CodCustId;
    private String Ktp;
    private String CusType;
    private String CusNamShrt;
    private String CusNamFirst;
    private String CusNamMid;
    private String CusNamLast;
    private String NoBatch;
    private int id;

    /**
     * @return the CodCustId
     */
    public String getCodCustId() {
        return CodCustId;
    }

    /**
     * @param CodCustId the CodCustId to set
     */
    public void setCodCustId(String CodCustId) {
        this.CodCustId = CodCustId;
    }

    /**
     * @return the Ktp
     */
    public String getKtp() {
        return Ktp;
    }

    /**
     * @param Ktp the Ktp to set
     */
    public void setKtp(String Ktp) {
        this.Ktp = Ktp;
    }

    /**
     * @return the CusType
     */
    public String getCusType() {
        return CusType;
    }

    /**
     * @param CusType the CusType to set
     */
    public void setCusType(String CusType) {
        this.CusType = CusType;
    }

    /**
     * @return the CusNamShrt
     */
    public String getCusNamShrt() {
        return CusNamShrt;
    }

    /**
     * @param CusNamShrt the CusNamShrt to set
     */
    public void setCusNamShrt(String CusNamShrt) {
        this.CusNamShrt = CusNamShrt;
    }

    /**
     * @return the CusNamFirst
     */
    public String getCusNamFirst() {
        return CusNamFirst;
    }

    /**
     * @param CusNamFirst the CusNamFirst to set
     */
    public void setCusNamFirst(String CusNamFirst) {
        this.CusNamFirst = CusNamFirst;
    }

    /**
     * @return the CusNamMid
     */
    public String getCusNamMid() {
        return CusNamMid;
    }

    /**
     * @param CusNamMid the CusNamMid to set
     */
    public void setCusNamMid(String CusNamMid) {
        this.CusNamMid = CusNamMid;
    }

    /**
     * @return the CusNamLast
     */
    public String getCusNamLast() {
        return CusNamLast;
    }

    /**
     * @param CusNamLast the CusNamLast to set
     */
    public void setCusNamLast(String CusNamLast) {
        this.CusNamLast = CusNamLast;
    }

    /**
     * @return the NoBatch
     */
    public String getNoBatch() {
        return NoBatch;
    }

    /**
     * @param NoBatch the NoBatch to set
     */
    public void setNoBatch(String NoBatch) {
        this.NoBatch = NoBatch;
    }

    /**
     * @return the ID
     */
    public int getid() {
        return id;
    }

    /**
     * @param id the ID to set
     */
    public void setid(int id) {
        this.id = id;
    }
    
}
