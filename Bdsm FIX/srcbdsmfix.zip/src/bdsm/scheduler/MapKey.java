/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsm.scheduler;

/**
 *
 * @author bdsm
 */
public class MapKey {

    /**
     * 
     */
    public static final String param1 = "param1";
    /**
     * 
     */
    public static final String param2 = "param2";
    /**
     * 
     */
    public static final String param3 = "param3";
    /**
     * 
     */
    public static final String param4 = "param4";
    /**
     * 
     */
    public static final String param5 = "param5";
    /**
     * 
     */
    public static final String param6 = "param6";
    /**
     * 
     */
    public static final String hdUserid = "idUser";
    /**
     * 
     */
    public static final String hdcdBranch = "cdBranch";
    /**
     * 
     */
    public static final String hdidTemplate = "idTemplate";
    /**
     * 
     */
    public static final String hddtProcess = "dtProcess";
    /**
     * 
     */
    public static final String hdnamUser = "namUser";
    /**
     * 
     */
    public static final String hdnamTemplate = "namTemplate";
    /**
     * 
     */
    public static final String idScheduler = "idScheduler";
    /**
     * 
     */
    public static final String filePattern = "filePattern";
    /**
     * 
     */
    public static final String fileName = "fileName";
    /**
     * 
     */
    public static final String filePath = "filePath";
    /**
     * 
     */
    public static final String fileBackup = "fileBackup";
    /**
     * 
     */
    public static final String importFileExtension = "importFileExtension";
    /**
     * 
     */
    public static final String status = "status";
    /**
     * 
     */
    public static final String batchNo = "batchNo";
    /**
     * 
     */
    public static final String model = "model";
    /**
     * 
     */
    public static final String fixQXtract = "fixQXtract";
    /**
     * 
     */
    public static final String session = "session";
    /**
     * 
     */
    public static final String javaClass = "javaClass";
    /**
     * 
     */
    public static final String templateName = "templateName";
    /**
     * 
     */
    public static final String grpId = "grpId";
    /**
     * 
     */
    public static final String inboxId = "inboxId";
    /**
     * 
     */
    public static final String itemIdLink = "itemIdLink";
    /**
     * 
     */
    public static final String cdAccess = "cdAccess";
    /**
     * 
     */
    public static final String spvAuth = "spvAuth";
    /**
     * 
     */
    public static final String flgEncrypt = "flgEncrypt";
    /**
     * 
     */
    public static final String modEncrypt = "modEncrypt";
    /**
     * 
     */
    public static final String modDecrypt = "modDecrypt";
    /**
     * 
     */
    public static final String keyEncrypt = "keyEncrypt";
    /**
     * 
     */
    public static final String keyDecrypt = "keyDecrypt";
    /**
     * 
     */
    public static final String reportId = "reportId";
    /**
     * 
     */
    public static final String reportFileName = "reportFileName";
    /**
     * 
     */
    public static final String reportFormat = "reportFormat";
    /**
     * 
     */
    public static final String reportParam = "reportParam";
    /**
     * 
     */
    public static final String processSource = "processSource";
    /**
     * 
     */
    public static final String typeFix = "typeFix";
    /**
     * 
     */
    public static final String emailSender = "emailSender";
    /**
     * 
     */
    public static final String flgChecksum = "flgChecksum";
    /**
     * 
     */
    public static final String dataSource = "dataSource";
    /**
     * 
     */
    public static final String errID = "errID";
    /**
     * 
     */
    public static final String flgCalendar = "flgCalendar";
    /**
     * 
     */
    public static final String schTimerProfile = "schTimerProfile";
    /**
     * 
     */
    public static final String extFile = "extFile";
}
