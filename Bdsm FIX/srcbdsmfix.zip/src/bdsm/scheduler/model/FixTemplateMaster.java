package bdsm.scheduler.model;

import bdsm.model.BaseModel;

/**
 * 
 * @author bdsm
 */
public class FixTemplateMaster extends BaseModel{
    private FixTemplateMasterPK fixTemplateMasterPK;    
    private String description;
    private String typFix;
    private String typTemplate;
    private String rptFileTemplate;
    private String javaClass;
    
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the typFix
     */
    public String getTypFix() {
        return typFix;
    }

    /**
     * @param typFix the typFix to set
     */
    public void setTypFix(String typFix) {
        this.typFix = typFix;
    }

    /**
     * @return the typTemplate
     */
    public String getTypTemplate() {
        return typTemplate;
    }

    /**
     * @param typTemplate the typTemplate to set
     */
    public void setTypTemplate(String typTemplate) {
        this.typTemplate = typTemplate;
    }

    /**
     * @return the rptFileTemplate
     */
    public String getRptFileTemplate() {
        return rptFileTemplate;
    }

    /**
     * @param rptFileTemplate the rptFileTemplate to set
     */
    public void setRptFileTemplate(String rptFileTemplate) {
        this.rptFileTemplate = rptFileTemplate;
    }

    /**
     * @return the javaClass
     */
    public String getJavaClass() {
        return javaClass;
    }

    /**
     * @param javaClass the javaClass to set
     */
    public void setJavaClass(String javaClass) {
        this.javaClass = javaClass;
    }

    /**
     * @return the fixTemplateMasterPK
     */
    public FixTemplateMasterPK getFixTemplateMasterPK() {
        return fixTemplateMasterPK;
    }

    /**
     * @param fixTemplateMasterPK the fixTemplateMasterPK to set
     */
    public void setFixTemplateMasterPK(FixTemplateMasterPK fixTemplateMasterPK) {
        this.fixTemplateMasterPK = fixTemplateMasterPK;
    }
    
}
