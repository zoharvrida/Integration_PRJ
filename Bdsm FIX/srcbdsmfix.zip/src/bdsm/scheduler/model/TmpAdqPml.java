/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsm.scheduler.model;

import bdsm.model.BaseModel;

/**
 *
 * @author NCBS
 */
public class TmpAdqPml extends BaseModel {

    private int id;
    private String batchNo;
    private String rowFlag;
    private String col1;
    private String col2;
    private String col3;
    private String col4;
    private String col5;
    private String col6;
    private String col7;
    private String col8;
    private String col9;
    private String col10;
    private String flgStatus;
    private String checksum;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the batchNo
     */
    public String getBatchNo() {
        return batchNo;
    }

    /**
     * @param batchNo the batchNo to set
     */
    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    /**
     * @return the rowFlag
     */
    public String getRowFlag() {
        return rowFlag;
    }

    /**
     * @param rowFlag the rowFlag to set
     */
    public void setRowFlag(String rowFlag) {
        this.rowFlag = rowFlag;
    }

    /**
     * @return the col1
     */
    public String getCol1() {
        return col1;
    }

    /**
     * @param col1 the col1 to set
     */
    public void setCol1(String col1) {
        this.col1 = col1;
    }

    /**
     * @return the col2
     */
    public String getCol2() {
        return col2;
    }

    /**
     * @param col2 the col2 to set
     */
    public void setCol2(String col2) {
        this.col2 = col2;
    }

    /**
     * @return the col3
     */
    public String getCol3() {
        return col3;
    }

    /**
     * @param col3 the col3 to set
     */
    public void setCol3(String col3) {
        this.col3 = col3;
    }

    /**
     * @return the col4
     */
    public String getCol4() {
        return col4;
    }

    /**
     * @param col4 the col4 to set
     */
    public void setCol4(String col4) {
        this.col4 = col4;
    }

    /**
     * @return the col5
     */
    public String getCol5() {
        return col5;
    }

    /**
     * @param col5 the col5 to set
     */
    public void setCol5(String col5) {
        this.col5 = col5;
    }

    /**
     * @return the col6
     */
    public String getCol6() {
        return col6;
    }

    /**
     * @param col6 the col6 to set
     */
    public void setCol6(String col6) {
        this.col6 = col6;
    }

    /**
     * @return the col7
     */
    public String getCol7() {
        return col7;
    }

    /**
     * @param col7 the col7 to set
     */
    public void setCol7(String col7) {
        this.col7 = col7;
    }

    /**
     * @return the col8
     */
    public String getCol8() {
        return col8;
    }

    /**
     * @param col8 the col8 to set
     */
    public void setCol8(String col8) {
        this.col8 = col8;
    }

    /**
     * @return the col9
     */
    public String getCol9() {
        return col9;
    }

    /**
     * @param col9 the col9 to set
     */
    public void setCol9(String col9) {
        this.col9 = col9;
    }

    /**
     * @return the col10
     */
    public String getCol10() {
        return col10;
    }

    /**
     * @param col10 the col10 to set
     */
    public void setCol10(String col10) {
        this.col10 = col10;
    }

    /**
     * @return the flgStatus
     */
    public String getFlgStatus() {
        return flgStatus;
    }

    /**
     * @param flgStatus the flgStatus to set
     */
    public void setFlgStatus(String flgStatus) {
        this.flgStatus = flgStatus;
    }

    /**
     * @return the checksum
     */
    public String getChecksum() {
        return checksum;
    }

    /**
     * @param checksum the checksum to set
     */
    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }
}
