/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsm.scheduler;

/**
 *
 * @author USER
 */
public interface IBdsmClass {
    /**
     * 
     * @return
     * @throws Exception
     */
    public boolean execute() throws Exception;
}
