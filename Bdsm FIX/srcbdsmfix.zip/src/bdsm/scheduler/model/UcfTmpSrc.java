/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsm.scheduler.model;

import bdsm.model.BaseModel;

/**
 *
 * @author NCBS
 */
public class UcfTmpSrc extends BaseModel {

    private String CodCustId;
    private String CodFieldTag;
    private String CodTask;
    private String FieldValue;
    private String Cmd;
    private String FlgStatus;
    private String NoBatch;
    private int Id;

    /**
     * @return the CodCustId
     */
    public String getCodCustId() {
        return CodCustId;
    }

    /**
     * @param CodCustId the CodCustId to set
     */
    public void setCodCustId(String CodCustId) {
        this.CodCustId = CodCustId;
    }

    /**
     * @return the CodFieldTag
     */
    public String getCodFieldTag() {
        return CodFieldTag;
    }

    /**
     * @param CodFieldTag the CodFieldTag to set
     */
    public void setCodFieldTag(String CodFieldTag) {
        this.CodFieldTag = CodFieldTag;
    }

    /**
     * @return the CodTask
     */
    public String getCodTask() {
        return CodTask;
    }

    /**
     * @param CodTask the CodTask to set
     */
    public void setCodTask(String CodTask) {
        this.CodTask = CodTask;
    }

    /**
     * @return the FieldValue
     */
    public String getFieldValue() {
        return FieldValue;
    }

    /**
     * @param FieldValue the FieldValue to set
     */
    public void setFieldValue(String FieldValue) {
        this.FieldValue = FieldValue;
    }

    /**
     * @return the Cmd
     */
    public String getCmd() {
        return Cmd;
    }

    /**
     * @param Cmd the Cmd to set
     */
    public void setCmd(String Cmd) {
        this.Cmd = Cmd;
    }

    /**
     * @return the FlgStatus
     */
    public String getFlgStatus() {
        return FlgStatus;
    }

    /**
     * @param FlgStatus the FlgStatus to set
     */
    public void setFlgStatus(String FlgStatus) {
        this.FlgStatus = FlgStatus;
    }

    /**
     * @return the NoBatch
     */
    public String getNoBatch() {
        return NoBatch;
    }

    /**
     * @param NoBatch the NoBatch to set
     */
    public void setNoBatch(String NoBatch) {
        this.NoBatch = NoBatch;
    }

    /**
     * @return the Id
     */
    public int getId() {
        return Id;
    }

    /**
     * @param Id the Id to set
     */
    public void setId(int Id) {
        this.Id = Id;
    }
}
