/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsm.scheduler.model;

import bdsm.model.BaseModel;
import java.util.Date;

/**
 *
 * @author v00020841
 */
public class TmpMaintenanceCim17ShareHold extends BaseModel {

    private TmpMaintenanceCim17ShareHoldPK compositeId;
    private String namMajShareHldr1;
    private String namMajShareHldr2;
    private String namMajShareHldr3;
    private String namMajShareHldr4;
    private String namMajShareHldr5;
    private String namMajShareHldr6;
    private String namMajShareHldr7;
    private String namMajShareHldr8;
    private String namMajShareHldr9;
    private String namMajShareHldr10;
    private String relationShip1;
    private String relationShip2;
    private String relationShip3;
    private String relationShip4;
    private String relationShip5;
    private String relationShip6;
    private String relationShip7;
    private String relationShip8;
    private String relationShip9;
    private String relationShip10;
    private String flagStatus;
    private String statusReason;

    /**
     * @return the namMajShareHldr1
     */
    public String getNamMajShareHldr1() {
        return namMajShareHldr1;
    }

    /**
     * @param namMajShareHldr1 the namMajShareHldr1 to set
     */
    public void setNamMajShareHldr1(String namMajShareHldr1) {
        this.namMajShareHldr1 = namMajShareHldr1;
    }

    /**
     * @return the namMajShareHldr2
     */
    public String getNamMajShareHldr2() {
        return namMajShareHldr2;
    }

    /**
     * @param namMajShareHldr2 the namMajShareHldr2 to set
     */
    public void setNamMajShareHldr2(String namMajShareHldr2) {
        this.namMajShareHldr2 = namMajShareHldr2;
    }

    /**
     * @return the namMajShareHldr3
     */
    public String getNamMajShareHldr3() {
        return namMajShareHldr3;
    }

    /**
     * @param namMajShareHldr3 the namMajShareHldr3 to set
     */
    public void setNamMajShareHldr3(String namMajShareHldr3) {
        this.namMajShareHldr3 = namMajShareHldr3;
    }

    /**
     * @return the namMajShareHldr4
     */
    public String getNamMajShareHldr4() {
        return namMajShareHldr4;
    }

    /**
     * @param namMajShareHldr4 the namMajShareHldr4 to set
     */
    public void setNamMajShareHldr4(String namMajShareHldr4) {
        this.namMajShareHldr4 = namMajShareHldr4;
    }

    /**
     * @return the namMajShareHldr5
     */
    public String getNamMajShareHldr5() {
        return namMajShareHldr5;
    }

    /**
     * @param namMajShareHldr5 the namMajShareHldr5 to set
     */
    public void setNamMajShareHldr5(String namMajShareHldr5) {
        this.namMajShareHldr5 = namMajShareHldr5;
    }

    /**
     * @return the namMajShareHldr6
     */
    public String getNamMajShareHldr6() {
        return namMajShareHldr6;
    }

    /**
     * @param namMajShareHldr6 the namMajShareHldr6 to set
     */
    public void setNamMajShareHldr6(String namMajShareHldr6) {
        this.namMajShareHldr6 = namMajShareHldr6;
    }

    /**
     * @return the namMajShareHldr7
     */
    public String getNamMajShareHldr7() {
        return namMajShareHldr7;
    }

    /**
     * @param namMajShareHldr7 the namMajShareHldr7 to set
     */
    public void setNamMajShareHldr7(String namMajShareHldr7) {
        this.namMajShareHldr7 = namMajShareHldr7;
    }

    /**
     * @return the namMajShareHldr8
     */
    public String getNamMajShareHldr8() {
        return namMajShareHldr8;
    }

    /**
     * @param namMajShareHldr8 the namMajShareHldr8 to set
     */
    public void setNamMajShareHldr8(String namMajShareHldr8) {
        this.namMajShareHldr8 = namMajShareHldr8;
    }

    /**
     * @return the namMajShareHldr9
     */
    public String getNamMajShareHldr9() {
        return namMajShareHldr9;
    }

    /**
     * @param namMajShareHldr9 the namMajShareHldr9 to set
     */
    public void setNamMajShareHldr9(String namMajShareHldr9) {
        this.namMajShareHldr9 = namMajShareHldr9;
    }

    /**
     * @return the namMajShareHldr10
     */
    public String getNamMajShareHldr10() {
        return namMajShareHldr10;
    }

    /**
     * @param namMajShareHldr10 the namMajShareHldr10 to set
     */
    public void setNamMajShareHldr10(String namMajShareHldr10) {
        this.namMajShareHldr10 = namMajShareHldr10;
    }

    /**
     * @return the relationShip1
     */
    public String getRelationShip1() {
        return relationShip1;
    }

    /**
     * @param relationShip1 the relationShip1 to set
     */
    public void setRelationShip1(String relationShip1) {
        this.relationShip1 = relationShip1;
    }

    /**
     * @return the relationShip2
     */
    public String getRelationShip2() {
        return relationShip2;
    }

    /**
     * @param relationShip2 the relationShip2 to set
     */
    public void setRelationShip2(String relationShip2) {
        this.relationShip2 = relationShip2;
    }

    /**
     * @return the relationShip3
     */
    public String getRelationShip3() {
        return relationShip3;
    }

    /**
     * @param relationShip3 the relationShip3 to set
     */
    public void setRelationShip3(String relationShip3) {
        this.relationShip3 = relationShip3;
    }

    /**
     * @return the relationShip4
     */
    public String getRelationShip4() {
        return relationShip4;
    }

    /**
     * @param relationShip4 the relationShip4 to set
     */
    public void setRelationShip4(String relationShip4) {
        this.relationShip4 = relationShip4;
    }

    /**
     * @return the relationShip5
     */
    public String getRelationShip5() {
        return relationShip5;
    }

    /**
     * @param relationShip5 the relationShip5 to set
     */
    public void setRelationShip5(String relationShip5) {
        this.relationShip5 = relationShip5;
    }

    /**
     * @return the relationShip6
     */
    public String getRelationShip6() {
        return relationShip6;
    }

    /**
     * @param relationShip6 the relationShip6 to set
     */
    public void setRelationShip6(String relationShip6) {
        this.relationShip6 = relationShip6;
    }

    /**
     * @return the relationShip7
     */
    public String getRelationShip7() {
        return relationShip7;
    }

    /**
     * @param relationShip7 the relationShip7 to set
     */
    public void setRelationShip7(String relationShip7) {
        this.relationShip7 = relationShip7;
    }

    /**
     * @return the relationShip8
     */
    public String getRelationShip8() {
        return relationShip8;
    }

    /**
     * @param relationShip8 the relationShip8 to set
     */
    public void setRelationShip8(String relationShip8) {
        this.relationShip8 = relationShip8;
    }

    /**
     * @return the relationShip9
     */
    public String getRelationShip9() {
        return relationShip9;
    }

    /**
     * @param relationShip9 the relationShip9 to set
     */
    public void setRelationShip9(String relationShip9) {
        this.relationShip9 = relationShip9;
    }

    /**
     * @return the relationShip10
     */
    public String getRelationShip10() {
        return relationShip10;
    }

    /**
     * @param relationShip10 the relationShip10 to set
     */
    public void setRelationShip10(String relationShip10) {
        this.relationShip10 = relationShip10;
    }

    /**
     * @return the compositeId
     */
    public TmpMaintenanceCim17ShareHoldPK getCompositeId() {
        return compositeId;
    }

    /**
     * @param compositeId the compositeId to set
     */
    public void setCompositeId(TmpMaintenanceCim17ShareHoldPK compositeId) {
        this.compositeId = compositeId;
    }
   
    /**
     * @return the flagStatus
     */
    public String getFlagStatus() {
        return flagStatus;
    }
    
    /**
     * @param flagStatus the flagStatus to set
     */
    public void setFlagStatus(String flagStatus) {
        this.flagStatus = flagStatus;
    }

    /**
     * @return the statusReason
     */
    public String getStatusReason() {
        return statusReason;
    }
   
    /**
     * @param statusReason the statusReason to set
     */
    public void setStatusReason(String statusReason) {
        this.statusReason = statusReason;
    }
}
